/**
 * Mon Chef V43 — Sanitation ↔ Checklists Automation Bridge.
 * Goal: one operational contour instead of two parallel forms.
 * Checklist = employee UI; V41/V42 = approved rules + execution + FACT.
 * No regulatory values are invented.
 */
const V43_SAN = {
  LINK:'Санитария_Чеклисты_Связи_V43',
  TASK:'Санитария_Задачи_V43',
  EXEC:'Санитария_ЧеклистФакты_V43',
  ALERT:'Санитария_АвтоАлерты_V43',
  GAP:'Санитария_ЧеклистПробелы_V43'
};
const V43_HEADERS = {
  LINK:['LinkID','ChecklistID','ItemID','ItemText','DisinfectantID','RegimeID','MatchMethod','Confidence','ApprovalStatus','Active','Notes','UpdatedAt'],
  TASK:['TaskID','ChecklistID','ItemID','DueAt','WindowMin','AssignedTo','AreaID','RegimeID','DisinfectantID','SolutionID','Status','Priority','CreatedAt','StartedAt','CompletedAt','CompletedBy','ExecutionID','FactID','DeviationID','Notes'],
  EXEC:['ExecutionID','TaskID','ChecklistID','ItemID','DateTime','EmployeeID','Status','Comment','DisinfectantID','RegimeID','SolutionID','MeasuredConcentration','ConcentrationUnit','ExpectedConcentration','Result','FactID','DeviationID','CreatedAt'],
  ALERT:['AlertID','AlertType','ObjectID','DateTime','Severity','Message','Status','TaskID','CreatedAt','ResolvedAt'],
  GAP:['GapID','ChecklistID','ItemID','ItemText','GapType','Description','Severity','Status','CreatedAt']
};
function _v43Sheet_(name,headers){var ss=_book_();var sh=ss.getSheetByName(name);if(!sh)sh=ss.insertSheet(name);if(sh.getLastRow()===0){sh.appendRow(headers);sh.setFrozenRows(1);}return sh;}
function _v43Rows_(name){var sh=_book_().getSheetByName(name);if(!sh||sh.getLastRow()<2)return[];var v=sh.getDataRange().getValues(),h=v[0],out=[];for(var i=1;i<v.length;i++){var r=v[i];if(!r.some(function(x){return x!=='';}))continue;var o={};h.forEach(function(k,j){o[k]=r[j];});o._row=r;o._rowNo=i+1;out.push(o);}return out;} // _rowNo — номер строки листа (раньше строку искали indexOf по объекту из другого чтения: -1 → запись в заголовок)
function _v43Id_(p){return 'SAN43-'+p+'-'+Utilities.getUuid().slice(0,8).toUpperCase();}
function setupV43SanitationChecklist(){Object.keys(V43_HEADERS).forEach(function(k){_v43Sheet_(V43_SAN[k],V43_HEADERS[k]);});if(typeof setupChecklists==='function')setupChecklists();if(typeof setupV42Sanitation==='function')setupV42Sanitation();if(typeof setupV41Disinfectants==='function')setupV41Disinfectants();return{ok:true,sheets:V43_SAN};}
function _v43Norm_(s){return String(s||'').toLowerCase().replace(/ё/g,'е').replace(/[^a-zа-я0-9]+/g,' ').trim().replace(/\s+/g,' ');}
function _v43ParseRange_(raw){var s=String(raw||'').replace(/,/g,'.');var m=s.match(/(\d+(?:\.\d+)?)\s*(?:-|–|—|до)\s*(\d+(?:\.\d+)?)\s*%/);if(m)return{min:Number(m[1]),max:Number(m[2])};m=s.match(/(\d+(?:\.\d+)?)\s*%/);if(m)return{min:Number(m[1]),max:Number(m[1])};return null;}
function _v43ApprovedRegimes_(){return _v43Rows_('Дезсредства_Режимы_V41').filter(function(r){return String(r.ApprovalStatus)==='APPROVED';}).map(function(r){var d=_v43Rows_('Дезсредства_V41').find(function(x){return String(x.DisinfectantID)===String(r.DisinfectantID);});return{r:r,d:d};}).filter(function(x){return x.d&&String(x.d.ApprovalStatus)==='APPROVED'&&String(x.d.AllowedForCatering)==='YES';});}
/** Сопоставление пунктов чек-листов с утверждёнными режимами V41. Автосопоставление НЕ утверждает связь (REVIEW):
 *  утверждает человек (v43ReviewLink). Решения людей (APPROVED/REJECTED) сохраняются при повторном запуске;
 *  связи, которые прежняя версия утвердила автоматически (Notes «Автосопоставление…»), возвращаются на проверку. */
function v43BuildChecklistLinks(){setupV43SanitationChecklist();
var links=_v43Sheet_(V43_SAN.LINK,V43_HEADERS.LINK),gaps=_v43Sheet_(V43_SAN.GAP,V43_HEADERS.GAP);
var keep={},kept=[];_v43Rows_(V43_SAN.LINK).forEach(function(x){var st=String(x.ApprovalStatus),auto=/^Автосопоставление/.test(String(x.Notes||''));if((st==='APPROVED'||st==='REJECTED')&&!auto){keep[String(x.ChecklistID)+'|'+String(x.ItemID)]=1;kept.push(V43_HEADERS.LINK.map(function(h){return x[h]===undefined?'':x[h];}));}});
if(links.getLastRow()>1)links.getRange(2,1,links.getLastRow()-1,links.getLastColumn()).clearContent();
if(gaps.getLastRow()>1)gaps.getRange(2,1,gaps.getLastRow()-1,gaps.getLastColumn()).clearContent();
var cls=JSON.parse(getChecklists()||'[]'),regimes=_v43ApprovedRegimes_(),now=new Date(),lr=[],gr=[];
cls.forEach(function(cl){(cl.items||[]).forEach(function(it){if(keep[String(cl.id)+'|'+String(it.id||'')])return;var dis=_v43Norm_(it.dis),conc=_v43Norm_(it.conc),text=_v43Norm_(it.text);if(!dis)return;
var cand=regimes.filter(function(x){return _v43Norm_(x.d.ProductName)===dis;});
if(!cand.length)cand=regimes.filter(function(x){return _v43Norm_(x.d.ProductName).indexOf(dis)>=0||dis.indexOf(_v43Norm_(x.d.ProductName))>=0;});
if(conc&&cand.length){var c2=cand.filter(function(x){return _v43Norm_(x.r.ConcentrationRaw)===conc;});if(c2.length)cand=c2;}
if(!cand.length){gr.push([_v43Id_('GAP'),cl.id,it.id||'',it.text||'','NO_APPROVED_REGIME','Нет утверждённого для общепита режима V41, соответствующего средству/концентрации пункта','HIGH','OPEN',now]);return;}
var best=cand[0],method='PRODUCT_NAME',conf=0.82;
if(cand.length>1){var obj=cand.find(function(x){return _v43Norm_(x.r.ObjectScope)&&text.indexOf(_v43Norm_(x.r.ObjectScope))>=0;});if(obj){best=obj;method='PRODUCT_OBJECT';conf=.93;}else{method='MULTIPLE_REVIEW';conf=.65;}}
lr.push([_v43Id_('LINK'),cl.id,it.id||'',it.text||'',best.d.DisinfectantID,best.r.RegimeID,method,conf,'REVIEW',true,'Кандидат ('+method+', уверенность '+conf+'; вариантов: '+cand.length+') — требуется проверка ответственным',now]);});});
var all=kept.concat(lr);if(all.length)links.getRange(2,1,all.length,V43_HEADERS.LINK.length).setValues(all);
if(gr.length)gaps.getRange(2,1,gr.length,gr[0].length).setValues(gr);
return{ok:true,links:lr.length,kept:kept.length,review:lr.length,gaps:gr.length};}
function _v43Link_(clId,itemId){return _v43Rows_(V43_SAN.LINK).find(function(x){return String(x.ChecklistID)===String(clId)&&String(x.ItemID)===String(itemId)&&String(x.Active)!=='false';})||null;}
function _v43ScheduleDue_(cl,base){var d=new Date(base);var dow=d.getDay();dow=dow===0?7:dow;var out=[];var hm=String(cl.time||'09:00').split(':');var hh=Number(hm[0]||9),mm=Number(hm[1]||0);function at(day){var x=new Date(day);x.setHours(hh,mm,0,0);return x;}if(cl.schedule==='daily_1x')out=[at(d)];else if(cl.schedule==='daily_2x')out=[at(d),new Date(at(d).getTime()+8*3600000)];else if(cl.schedule==='weekly'&&dow===1)out=[at(d)];else if(cl.schedule==='monthly'&&d.getDate()===1)out=[at(d)];return out;}
function _v43AlreadyTask_(clId,itemId,due){var ds=_v43Rows_(V43_SAN.TASK),key=new Date(due).getTime();return ds.some(function(x){return String(x.ChecklistID)===String(clId)&&String(x.ItemID)===String(itemId)&&x.DueAt instanceof Date&&new Date(x.DueAt).getTime()===key;});}
function v43GenerateTasks(baseDate,token){setupV43SanitationChecklist();var d=baseDate?new Date(baseDate):new Date();var cls=JSON.parse(getChecklists()||'[]').filter(function(c){return c.active!==false;});var sh=_v43Sheet_(V43_SAN.TASK,V43_HEADERS.TASK),rows=[],links=_v43Rows_(V43_SAN.LINK),now=new Date();cls.forEach(function(cl){_v43ScheduleDue_(cl,d).forEach(function(due){if(due>new Date(d.getTime()+24*3600000))return;(cl.items||[]).forEach(function(it){var link=links.find(function(x){return String(x.ChecklistID)===String(cl.id)&&String(x.ItemID)===String(it.id||'');});if(!link||String(link.ApprovalStatus)!=='APPROVED')return;if(_v43AlreadyTask_(cl.id,it.id,due))return;var rid=link.RegimeID, did=link.DisinfectantID;rows.push([_v43Id_('TASK'),cl.id,it.id,due,60,cl.role||'', '',rid,did,'','OPEN','NORMAL',now,'','','','','','','Автоматически из расписания чек-листа']);});});});if(rows.length)sh.getRange(sh.getLastRow()+1,1,rows.length,rows[0].length).setValues(rows);return{ok:true,created:rows.length};}
function v43GetMyTasks(employee,token){setupV43SanitationChecklist();var now=new Date(),rows=_v43Rows_(V43_SAN.TASK).filter(function(x){return String(x.Status)==='OPEN'||String(x.Status)==='IN_PROGRESS';}).filter(function(x){return !employee||!x.AssignedTo||String(x.AssignedTo)===String(employee);}).filter(function(x){return x.DueAt instanceof Date && x.DueAt<=new Date(now.getTime()+24*3600000);});return rows.map(function(x){var cl=JSON.parse(getChecklists()||'[]').find(function(c){return String(c.id)===String(x.ChecklistID);}),it=cl&&cl.items?cl.items.find(function(i){return String(i.id||'')===String(x.ItemID);}):null;return{taskId:x.TaskID,checklistId:x.ChecklistID,checklistName:cl?cl.name:'',itemId:x.ItemID,text:it?it.text:'',dueAt:x.DueAt,regimeId:x.RegimeID,disinfectantId:x.DisinfectantID,solutionId:x.SolutionID,status:x.Status,priority:x.Priority};});}
function v43StartTask(taskId,employee,token){var sh=_v43Sheet_(V43_SAN.TASK,V43_HEADERS.TASK),x=_v43Rows_(V43_SAN.TASK).find(function(r){return String(r.TaskID)===String(taskId);});if(!x)throw new Error('Task not found');var row=x._row, h=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0],ri=x._rowNo;sh.getRange(ri,h.indexOf('Status')+1).setValue('IN_PROGRESS');sh.getRange(ri,h.indexOf('StartedAt')+1).setValue(new Date());sh.getRange(ri,h.indexOf('AssignedTo')+1).setValue(employee||x.AssignedTo||'');return{ok:true,taskId:taskId};}
/** ИСПОЛНЕНИЕ пункта: задача — «выполнена» (DONE), результат отдельно — OK или DEVIATION. Отклонение открывает нарушение
 *  (v43ResolveDeviation → v43VerifyDeviation). Исполнитель — из серверной сессии, а не из браузера. Если режим задаёт
 *  концентрацию, нужно числовое измерение: галочка его не заменяет; вне диапазона — отклонение. */
function v43CompleteChecklistItem(p,token){setupV43SanitationChecklist();p=p||{};if(!p.taskId)throw new Error('Не выбрана задача');
return _withLock_(function(){var tasks=_v43Rows_(V43_SAN.TASK),t=tasks.find(function(x){return String(x.TaskID)===String(p.taskId);});if(!t)throw new Error('Задача не найдена');
if(String(t.Status)==='DONE')return{ok:true,idempotent:true,taskId:p.taskId};
var link=_v43Link_(t.ChecklistID,t.ItemID);if(!link||String(link.ApprovalStatus)!=='APPROVED')throw new Error('Связь пункта с режимом дезсредства не утверждена — выполнение не записывается');
var who=_v43Who_(),reg=_v43ApprovedRegimes_().find(function(x){return String(x.r.RegimeID)===String(t.RegimeID);}),range=reg?_v43ParseRange_(reg.r.ConcentrationRaw):null;
var raw=String(p.measuredConcentration===undefined?'':p.measuredConcentration).replace(',','.').trim(),meas=raw===''?null:Number(raw);
if(range&&String(p.status||'DONE').toUpperCase()!=='FAILED'){if(meas===null||isNaN(meas))throw new Error('Режим задаёт концентрацию '+reg.r.ConcentrationRaw+' — введите измеренное значение (галочка его не заменяет)');}
if(meas!==null&&isNaN(meas))throw new Error('Концентрация — число');
var outOfRange=range&&meas!==null&&(meas<range.min||meas>range.max);
var result=String(p.status||'DONE').toUpperCase()==='FAILED'||outOfRange?'DEVIATION':'OK',execId=_v43Id_('EXEC'),factId=_v43Id_('FACT'),now=new Date(),es=_v43Sheet_(V43_SAN.EXEC,V43_HEADERS.EXEC),aid='';
if(result==='DEVIATION')aid=v43CreateAlert_('SANITATION_FAILED',t.TaskID,'HIGH',outOfRange?'Концентрация '+meas+' вне режима '+reg.r.ConcentrationRaw:'Санитарный пункт отмечен как отклонение: '+(p.comment||''),t.TaskID);
es.appendRow([execId,t.TaskID,t.ChecklistID,t.ItemID,now,who.name,'DONE',p.comment||'',t.DisinfectantID,t.RegimeID,p.solutionId||t.SolutionID||'',meas===null?'':meas,p.concentrationUnit||'%',reg?reg.r.ConcentrationRaw:'',result,factId,aid,now]);
var sh=_v43Sheet_(V43_SAN.TASK,V43_HEADERS.TASK),idx=t._rowNo,h=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
sh.getRange(idx,h.indexOf('Status')+1).setValue('DONE');sh.getRange(idx,h.indexOf('CompletedAt')+1).setValue(now);sh.getRange(idx,h.indexOf('CompletedBy')+1).setValue(who.name);
sh.getRange(idx,h.indexOf('ExecutionID')+1).setValue(execId);sh.getRange(idx,h.indexOf('FactID')+1).setValue(factId);if(aid)sh.getRange(idx,h.indexOf('DeviationID')+1).setValue(aid);
return{ok:true,executionId:execId,factId:factId,executed:true,result:result,deviationId:aid};});}
function v43CreateAlert_(type,obj,sev,msg,task){var sh=_v43Sheet_(V43_SAN.ALERT,V43_HEADERS.ALERT),id=_v43Id_('ALT'),now=new Date();sh.appendRow([id,type,obj,now,sev,msg,'OPEN',task||'',now,'']);return id;}
/** Просрочка: одно уведомление на задачу (повторный запуск по расписанию не создаёт дублей). */
function v43BuildOverdueAlerts(){setupV43SanitationChecklist();var now=new Date(),out=[],rows=_v43Rows_(V43_SAN.TASK),have={};
_v43Rows_(V43_SAN.ALERT).forEach(function(a){if(String(a.AlertType)==='SANITATION_OVERDUE')have[String(a.TaskID||a.ObjectID)]=1;});
rows.forEach(function(t){if((String(t.Status)==='OPEN'||String(t.Status)==='IN_PROGRESS')&&t.DueAt instanceof Date&&new Date(t.DueAt).getTime()+60*60000<now.getTime()&&!have[String(t.TaskID)]){have[String(t.TaskID)]=1;out.push(v43CreateAlert_('SANITATION_OVERDUE',t.TaskID,'MEDIUM','Санитарная задача просрочена',t.TaskID));}});
return{ok:true,created:out.length};}
function v43AutomationTick(){setupV43SanitationChecklist();var r1=v43GenerateTasks(new Date(),'');var r2=v43BuildOverdueAlerts();try{if(typeof v42BuildAlerts==='function')v42BuildAlerts();}catch(e){}return{ok:true,tasks:r1,alerts:r2};}
function v43InstallAutomation(){ScriptApp.getProjectTriggers().forEach(function(t){if(t.getHandlerFunction()==='v43AutomationTick')ScriptApp.deleteTrigger(t);});ScriptApp.newTrigger('v43AutomationTick').timeBased().everyHours(1).create();return{ok:true,trigger:'hourly'};}
function v43GetDashboard(){setupV43SanitationChecklist();var out={};Object.keys(V43_SAN).forEach(function(k){var sh=_book_().getSheetByName(V43_SAN[k]);out[V43_SAN[k]]=sh?Math.max(0,sh.getLastRow()-1):0;});out.openTasks=_v43Rows_(V43_SAN.TASK).filter(function(x){return String(x.Status)==='OPEN'||String(x.Status)==='IN_PROGRESS';}).length;out.overdueTasks=_v43Rows_(V43_SAN.TASK).filter(function(x){return(String(x.Status)==='OPEN'||String(x.Status)==='IN_PROGRESS')&&x.DueAt instanceof Date&&x.DueAt.getTime()+3600000<new Date().getTime();}).length;out.openGaps=_v43Rows_(V43_SAN.GAP).filter(function(x){return String(x.Status)==='OPEN';}).length;return out;}

/* ------------------------------------------------------------------ проверка связей и жизненный цикл нарушения */
function _v43Who_(){var s=null;try{s=typeof mcGateSession_==='function'?mcGateSession_():null;}catch(e){}return{name:s?String(s.fullName||s.name||''):'',id:s?String(s.user_id||''):'',role:s?String(s.role||''):''};}
function _v43SetRow_(key,id,patch){var sh=_v43Sheet_(V43_SAN[key],V43_HEADERS[key]),rows=_v43Rows_(V43_SAN[key]),col0=V43_HEADERS[key][0],x=rows.find(function(r){return String(r[col0])===String(id);});if(!x)throw new Error('NOT_FOUND: '+id);
var h=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];Object.keys(patch).forEach(function(k){var c=h.indexOf(k);if(c>=0)sh.getRange(x._rowNo,c+1).setValue(patch[k]);});return x;}
/** Ответственный утверждает или отклоняет связь пункта чек-листа с режимом дезсредства. */
function v43ReviewLink(linkId,decision,comment,token){decision=String(decision||'').toUpperCase();if(['APPROVED','REJECTED'].indexOf(decision)<0)throw new Error('Решение — APPROVED или REJECTED');
return _withLock_(function(){var who=_v43Who_(),x=_v43SetRow_('LINK',linkId,{ApprovalStatus:decision,Notes:'Проверил: '+(who.name||'—')+', '+Utilities.formatDate(new Date(),_mcTz_(),'dd.MM.yyyy HH:mm')+(comment?'; '+comment:''),UpdatedAt:new Date()});
try{_audit_({session:null,id:'V43'},'V43_LINK_REVIEW','Санитария_Связь',linkId,x.ApprovalStatus,{status:decision,by:who.name});}catch(e){}return{ok:true,linkId:linkId,status:decision};});}
/** УСТРАНЕНИЕ нарушения (отдельно от исполнения): корректирующее действие → «ожидает проверки». */
function v43ResolveDeviation(alertId,correctiveAction,token){if(!String(correctiveAction||'').trim())throw new Error('Опишите корректирующее действие');
return _withLock_(function(){var who=_v43Who_(),a=_v43Rows_(V43_SAN.ALERT).find(function(r){return String(r.AlertID)===String(alertId);});if(!a)throw new Error('Нарушение не найдено');
if(['OPEN','IN_PROGRESS','REOPENED'].indexOf(String(a.Status))<0)throw new Error('Нарушение в статусе '+a.Status+' — устранение уже записано');
_v43SetRow_('ALERT',alertId,{Status:'VERIFY_REQUIRED',Message:String(a.Message)+' | Устранено: '+correctiveAction+' ('+(who.name||'—')+', '+Utilities.formatDate(new Date(),_mcTz_(),'dd.MM.yyyy HH:mm')+')'});return{ok:true,alertId:alertId,status:'VERIFY_REQUIRED'};});}
/** ПРОВЕРКА устранения: закрывает только другой сотрудник; не подтверждено — нарушение снова открыто. */
function v43VerifyDeviation(alertId,confirmed,comment,token){return _withLock_(function(){var who=_v43Who_(),a=_v43Rows_(V43_SAN.ALERT).find(function(r){return String(r.AlertID)===String(alertId);});if(!a)throw new Error('Нарушение не найдено');
if(String(a.Status)!=='VERIFY_REQUIRED')throw new Error('Проверять можно нарушение «ожидает проверки»');
var m=/Устранено: .*\((.*?), \d\d\.\d\d\.\d{4}/.exec(String(a.Message));if(m&&who.name&&m[1]===who.name)throw new Error('Устранение подтверждает другой сотрудник');
var ok=confirmed===true||String(confirmed)==='true';_v43SetRow_('ALERT',alertId,{Status:ok?'CLOSED':'REOPENED',ResolvedAt:ok?new Date():'',Message:String(a.Message)+' | Проверка: '+(ok?'подтверждено':'не подтверждено')+(comment?' — '+comment:'')+' ('+(who.name||'—')+')'});
return{ok:true,alertId:alertId,status:ok?'CLOSED':'REOPENED'};});}
function v43GetLinks(token){setupV43SanitationChecklist();return _v43Rows_(V43_SAN.LINK).map(function(x){return{linkId:x.LinkID,checklistId:x.ChecklistID,itemId:x.ItemID,text:x.ItemText,disinfectantId:x.DisinfectantID,regimeId:x.RegimeID,method:x.MatchMethod,confidence:x.Confidence,status:x.ApprovalStatus,notes:x.Notes};});}
function v43GetDeviations(token){setupV43SanitationChecklist();return _v43Rows_(V43_SAN.ALERT).filter(function(a){return String(a.AlertType)==='SANITATION_FAILED'&&String(a.Status)!=='CLOSED';}).map(function(a){return{alertId:a.AlertID,taskId:a.TaskID,at:a.DateTime,message:a.Message,status:a.Status,severity:a.Severity};});}
