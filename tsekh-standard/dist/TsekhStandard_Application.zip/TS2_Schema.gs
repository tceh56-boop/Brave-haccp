/**
 * ЦЕХ Стандарт 2.0 — схема базы предприятия (ТЗ 2.0 §7, ТЗ 2.1 §11, ТЗ 2.2 §5).
 *
 * Единственный источник заголовков канонических листов. Из этого же описания tools/gen_artifacts_2.js
 * собирает ENTERPRISE_SCHEMA_2.0.md, поэтому документация и код не расходятся.
 *
 * Совместимость (ТЗ 2.0 §15.1): существующие листы ЦЕХ Стандарт не переименовываются и не удаляются.
 * Имена листов Google Таблиц не различают регистр, поэтому:
 *   • канонический AUDIT_LOG ведётся в листе AUDIT_CHAIN (цепочка хешей) — прежний «Audit_Log» остаётся и
 *     подключается адаптером;
 *   • TRACE_LINKS — существующий лист (ТЗ: TRACE_LINKS → TRACE_LINKS);
 *   • OPERATIONS → существующий лист «Операции», FACTS → «Факты» (адаптеры TS2_LEGACY_MAP_).
 */
var TS2_SCHEMA_VERSION = '2.2.0';

// лист → { prefix: префикс ID, head: колонки, group: раздел ТЗ, note }
var TS2_ENTERPRISE_SCHEMA_ = {
  // ---------------- ТЗ 2.0 §7.1 системные листы
  SYSTEM_CONFIG: { group: '2.0 §7.2', head: ['key', 'value', 'valueType', 'scope', 'isSecret', 'source', 'status', 'updatedAt', 'updatedBy'], note: 'Параметры предприятия. Секреты — только в Script Properties (здесь isSecret=TRUE и пустое value).' },
  ID_COUNTERS: { group: '2.0 §7.3', head: ['counterCode', 'prefix', 'year', 'lastNumber', 'updatedAt', 'updatedBy'], note: 'Счётчики ID. Генератор под общей блокировкой, идемпотентен по idempotencyKey.' },
  SCHEMA_VERSION: { group: '2.0 §7.1', head: ['version', 'appliedAt', 'appliedBy', 'sheetsCreated', 'sheetsVerified', 'notes'] },
  DRIVE_REGISTRY: { group: '2.0 §7.4', prefix: 'DRV', head: ['resourceId', 'enterpriseId', 'resourceType', 'logicalCode', 'name', 'googleId', 'parentGoogleId', 'url', 'status', 'lastCheckedAt', 'hash'] },
  FILES: { group: '2.0 §7.5', prefix: 'FILE', yearly: true, head: ['fileId', 'enterpriseId', 'googleFileId', 'googleUrl', 'fileName', 'mimeType', 'sizeBytes', 'sha256', 'parentFolderId', 'entityType', 'entityId', 'documentId', 'source', 'uploadedBy', 'uploadedAt', 'lastSeenAt', 'status', 'isOriginal', 'isPreview'] },
  DOCUMENTS: { group: '2.0 §7.6', prefix: 'DOC', yearly: true, head: ['documentId', 'enterpriseId', 'documentType', 'title', 'number', 'documentDate', 'validFrom', 'validTo', 'counterpartyId', 'entityType', 'entityId', 'currentVersionId', 'status', 'sourceFileId', 'ownerEmployeeId', 'createdAt', 'updatedAt'] },
  DOCUMENT_VERSIONS: { group: '2.0 §7.7', prefix: 'DOCV', yearly: true, head: ['documentVersionId', 'documentId', 'versionNumber', 'fileId', 'extractedTextFileId', 'extractedDataJsonFileId', 'sha256', 'parser', 'parserVersion', 'confidence', 'status', 'changeSummary', 'createdAt', 'createdBy', 'approvedAt', 'approvedBy'] },
  IMPORT_JOBS: { group: '2.0 §7.8', prefix: 'IMP', yearly: true, head: ['importJobId', 'enterpriseId', 'sourceType', 'sourceFolderId', 'fileCount', 'rowCount', 'status', 'stage', 'profileId', 'startedAt', 'completedAt', 'startedBy', 'errorCount', 'warningCount', 'reportFileId'] },
  IMPORT_ITEMS: { group: '2.0 §7.9', prefix: 'IMPI', yearly: true, head: ['importItemId', 'importJobId', 'fileId', 'rowNumber', 'sourceObjectType', 'sourceObjectName', 'rawDataJson', 'normalizedDataJson', 'matchedEntityType', 'matchedEntityId', 'confidence', 'status', 'issuesJson', 'reviewedBy', 'reviewedAt'] },
  RECONCILIATION_RUNS: { group: '2.0 §7.10', prefix: 'REC', yearly: true, head: ['reconciliationRunId', 'enterpriseId', 'profileId', 'scope', 'sourceSnapshot', 'startedAt', 'completedAt', 'status', 'passCount', 'reviewCount', 'failCount', 'missingCount', 'notApplicableCount', 'reportFileId', 'createdBy'] },
  RECONCILIATION_ISSUES: { group: '2.0 §7.11', prefix: 'ISS', yearly: true, head: ['issueId', 'reconciliationRunId', 'enterpriseId', 'ruleId', 'severity', 'entityType', 'entityId', 'sourceDocumentId', 'fieldName', 'currentValue', 'expectedValue', 'message', 'suggestedAction', 'status', 'ownerRole', 'assignedTo', 'dueAt', 'resolvedAt', 'resolvedBy', 'resolutionComment', 'evidenceFileId'] },
  CHANGE_PROPOSALS: { group: '2.0 §7.12', prefix: 'CHG', yearly: true, head: ['changeProposalId', 'issueId', 'enterpriseId', 'entityType', 'entityId', 'operationType', 'beforeJson', 'afterJson', 'reason', 'basisDocumentId', 'riskLevel', 'requiresBackup', 'requiresApproval', 'status', 'createdAt', 'createdBy', 'approvedAt', 'approvedBy', 'appliedAt', 'appliedBy', 'rollbackAvailable', 'rollbackDataFileId'] },
  APPROVALS: { group: '2.0 §7.13', prefix: 'APR', yearly: true, head: ['approvalId', 'changeProposalId', 'enterpriseId', 'approvalType', 'requestedFromRole', 'requestedFromEmployeeId', 'requestedAt', 'status', 'approvedBy', 'approvedAt', 'rejectedBy', 'rejectedAt', 'comment'] },
  MIGRATION_MAP: { group: '2.0 §7.14', prefix: 'MIG', yearly: true, head: ['migrationMapId', 'enterpriseId', 'sourceSystem', 'sourceSheet', 'sourceKey', 'sourceRow', 'legacyValue', 'entityType', 'entityId', 'mappingMethod', 'confidence', 'status', 'reviewedBy', 'reviewedAt', 'notes'] },
  AUDIT_CHAIN: { group: '2.0 §7.16 (AUDIT_LOG)', prefix: 'AUD', yearly: true, head: ['auditId', 'operationId', 'enterpriseId', 'actorType', 'actorId', 'actorName', 'actorRole', 'action', 'entityType', 'entityId', 'beforeJson', 'afterJson', 'reason', 'source', 'result', 'createdAt', 'prevHash', 'hash'], note: 'Канонический AUDIT_LOG. Только дописывается; hash = SHA-256(prevHash|строка). Лист защищён от правки.' },
  BACKUP_CATALOG: { group: '2.0 §7.18', prefix: 'BKP', yearly: true, head: ['backupId', 'enterpriseId', 'backupType', 'scope', 'fileId', 'fileUrl', 'createdAt', 'createdBy', 'sizeBytes', 'sha256', 'schemaVersion', 'status', 'restoreTestedAt', 'restoreResult'] },
  READINESS_RUNS: { group: '2.0 §7.19', prefix: 'RDY', yearly: true, head: ['readinessRunId', 'enterpriseId', 'runType', 'startedAt', 'completedAt', 'status', 'passCount', 'failCount', 'reviewCount', 'missingEvidenceCount', 'detailsJson', 'reportFileId', 'createdBy'] },
  // ---------------- ТЗ 2.0 §8 структура предприятия (новые канонические реестры)
  LOCATIONS: { group: '2.0 §8.1', prefix: 'LOC', yearly: true, head: ['locationId', 'enterpriseId', 'organizationId', 'name', 'address', 'locationType', 'status', 'notApplicableReason', 'createdAt', 'createdBy'] },
  WORKSHOPS: { group: '2.0 §8.1', prefix: 'WS', head: ['workshopId', 'enterpriseId', 'locationId', 'code', 'name', 'zoneType', 'status', 'notApplicableReason', 'legacyName', 'createdAt', 'createdBy'] },
  ROLE_PERMISSIONS: { group: '2.0 §8.2', head: ['roleCode', 'roleName', 'actionCode', 'allowed', 'source', 'version', 'updatedAt'] },
  // ---------------- ТЗ 2.1 §11
  SYSTEM_DOCUMENTS: { group: '2.1 §11.1', prefix: 'SDOC', yearly: true, head: ['documentId', 'enterpriseId', 'templateId', 'templateVersion', 'documentType', 'title', 'approvalMode', 'status', 'requiresLocalApproval', 'localApprovalStatus', 'source', 'fileId', 'validFrom', 'validTo', 'createdAt', 'updatedAt', 'approvedByEnterprise', 'approvedAt'] },
  EVENT_RULES: { group: '2.1 §8.1', head: ['eventRuleId', 'enterpriseId', 'eventType', 'sourceEntityType', 'sourceEvent', 'createsRecordType', 'journalCode', 'haccpControlPointId', 'requiredConfirmation', 'measurementMode', 'defaultResult', 'notificationRuleId', 'active', 'version', 'title', 'sourceTtkId'] },
  AUTO_RECORDS: { group: '2.1 §11.3', prefix: 'ARC', yearly: true, head: ['autoRecordId', 'enterpriseId', 'eventType', 'sourceType', 'sourceId', 'recordType', 'journalCode', 'kktId', 'productionId', 'batchId', 'ttkId', 'result', 'measurementMode', 'value', 'unit', 'createdAt', 'createdBySystem', 'confidence', 'status', 'idempotencyKey', 'operationId', 'confirmedByEmployee', 'confirmedAt', 'ruleVersion', 'schemaVersion', 'prevHash', 'hash'] },
  MANUAL_MEASUREMENTS: { group: '2.1 §11.4', prefix: 'MSR', yearly: true, head: ['measurementId', 'enterpriseId', 'measurementType', 'objectType', 'objectId', 'value', 'unit', 'minValue', 'maxValue', 'result', 'employeeId', 'recordedAt', 'source', 'comment', 'photoFileId', 'operationId'] },
  JOURNAL_EXPECTATIONS: { group: '2.1 §11.5', prefix: 'EXP', yearly: true, head: ['expectationId', 'enterpriseId', 'journalCode', 'eventRuleId', 'objectType', 'objectId', 'productionId', 'batchId', 'dueAt', 'responsibleRole', 'status', 'confirmationMode', 'measurementRequired', 'completedAt', 'completedBy', 'factId', 'title', 'idempotencyKey'] },
  APPROVAL_QUEUE: { group: '2.1 §11.6', prefix: 'APQ', yearly: true, head: ['approvalId', 'enterpriseId', 'objectType', 'objectId', 'title', 'reason', 'preparedBySystem', 'requiredRole', 'status', 'approvedBy', 'approvedAt', 'comment'] },
  MEASUREMENT_OBJECTS: { group: '2.1 §6.3, §10', prefix: 'OBJ', yearly: false, head: ['objectId', 'enterpriseId', 'objectType', 'name', 'workshopId', 'minValue', 'maxValue', 'unit', 'setpoint', 'checkTimes', 'legacyObjectId', 'status', 'notApplicableReason', 'lastReplacedAt', 'resourceHours', 'createdAt', 'createdBy', 'inputMode'], note: 'inputMode: MANUAL — замер делает повар, SENSOR — датчик (время замеров одно — checkTimes). Объекты замеров: холодильники, морозильники, помещения (t°, влажность), фритюрницы, бактерицидные лампы. Пределы вводит предприятие по документу.' },
  SENSOR_DEVICES: { group: '2.1 §7.3 (датчики)', prefix: 'SNS', yearly: false, head: ['deviceId', 'enterpriseId', 'objectId', 'name', 'tokenHash', 'status', 'createdAt', 'createdBy', 'lastSeenAt', 'lastValue', 'lastResult', 'lastStoredAt', 'revokedAt', 'lastRaw', 'offset', 'calibratedAt', 'calibratedBy', 'rssi', 'silentNotifiedAt'], note: 'Датчики температуры и влажности. Ключ устройства хранится только хешем, показывается один раз при подключении. offset — поправка по сверке с поверенным термометром.' },
  SENSOR_CALIBRATIONS: { group: '2.1 §7.3 (датчики)', prefix: 'SCAL', yearly: false, head: ['calibrationId', 'enterpriseId', 'deviceId', 'objectId', 'referenceValue', 'referenceThermometer', 'sensorRaw', 'offsetBefore', 'offsetAfter', 'difference', 'result', 'calibratedBy', 'calibratedAt', 'comment'], note: 'Сверка датчика с поверенным термометром: показание эталона, сырое показание датчика, поправка до и после.' },
  AUTOMATION_PROFILE: { group: '2.1 §3, §12', head: ['key', 'value', 'updatedAt', 'updatedBy'], note: 'Режим READY_TO_WORK / PILOT / CUSTOM, тип предприятия, политика ручного ввода.' },
  // ---------------- ТЗ 2.2 §5
  TTK_SOURCE_FACTS: { group: '2.2 §5.1', prefix: 'TSF', yearly: true, head: ['sourceFactId', 'enterpriseId', 'ttkId', 'ttkVersionId', 'fieldCode', 'rawValue', 'normalizedValue', 'unit', 'confidence', 'sourceFileId', 'sourcePage', 'sourceText', 'extractionMethod', 'status', 'requiresReview', 'createdAt'] },
  DOCUMENT_GENERATION_JOBS: { group: '2.2 §5.2', prefix: 'GEN', yearly: true, head: ['generationJobId', 'enterpriseId', 'ttkVersionId', 'generationType', 'profileId', 'status', 'startedAt', 'completedAt', 'requestedBy', 'backupId', 'createdDocumentCount', 'createdIssueCount', 'createdRuleCount', 'errorMessage', 'reportFileId', 'ttkId', 'summaryJson'] },
  DOCUMENT_GENERATION_ITEMS: { group: '2.2 §5.3', prefix: 'GENI', yearly: true, head: ['generationItemId', 'generationJobId', 'documentType', 'sectionCode', 'fieldCode', 'value', 'sourceType', 'sourceId', 'confidence', 'status', 'requiresApproval', 'issueId'] },
  TU_DOCUMENTS: { group: '2.2 §5.4', prefix: 'TU', yearly: true, head: ['tuId', 'enterpriseId', 'tuNumber', 'title', 'productGroup', 'version', 'status', 'sourceTtkIds', 'sourceNormIds', 'fileId', 'validFrom', 'validTo', 'approvedBy', 'approvedAt', 'createdAt', 'generationJobId', 'pdfFileId', 'hash'] },
  STO_DOCUMENTS: { group: '2.2 §5.5', prefix: 'STO', yearly: true, head: ['stoId', 'enterpriseId', 'stoNumber', 'title', 'processCode', 'workshopId', 'version', 'status', 'sourceTtkIds', 'sourceEquipmentIds', 'sourceRuleIds', 'fileId', 'approvedBy', 'approvedAt', 'createdAt', 'generationJobId', 'pdfFileId', 'hash'] },
  PPK_DOCUMENTS: { group: '2.2 §5.6', prefix: 'PPK', yearly: true, head: ['ppkId', 'enterpriseId', 'name', 'version', 'baseVersionId', 'changeType', 'changeReason', 'status', 'sourceTtkIds', 'sourceStoIds', 'sourceHaccpProcessIds', 'fileId', 'approvedBy', 'approvedAt', 'validFrom', 'validTo', 'createdAt', 'generationJobId', 'pdfFileId', 'hash'] },
  DOCUMENT_SOURCE_LINKS: { group: '2.2 §5.7', prefix: 'DSL', yearly: true, head: ['linkId', 'enterpriseId', 'targetDocumentType', 'targetDocumentId', 'sourceType', 'sourceId', 'sourceField', 'relation', 'createdAt'] },
  DOCUMENT_GENERATION_ISSUES: { group: '2.2 §5.8', prefix: 'GISS', yearly: true, head: ['issueId', 'generationJobId', 'enterpriseId', 'severity', 'sectionCode', 'fieldCode', 'message', 'currentValue', 'requiredValue', 'suggestedAction', 'status', 'assignedRole', 'resolvedBy', 'resolvedAt'] },
  HACCP_PROCESSES_V2: { group: '2.2 §7.1', prefix: 'HPR', yearly: true, head: ['processId', 'enterpriseId', 'processCode', 'name', 'sourceTtkId', 'operationOrder', 'workshopId', 'status', 'createdAt'] },
  HACCP_HAZARDS_V2: { group: '2.2 §4 этап 5', prefix: 'HZ', yearly: true, head: ['hazardId', 'enterpriseId', 'processId', 'hazardType', 'description', 'masterHazardCode', 'confidence', 'status', 'basis', 'createdAt'] },
  HACCP_CONTROLS_V2: { group: '2.2 §7.1', prefix: 'KKT', yearly: true, head: ['controlId', 'enterpriseId', 'processId', 'hazardId', 'name', 'isCcp', 'criticalLimit', 'limitSource', 'monitoringMethod', 'frequency', 'responsibleRole', 'journalCode', 'correctiveAction', 'sourceTtkId', 'sourceStoId', 'sourcePpkId', 'status', 'createdAt'] }
};

// Существующие листы → канонические сущности (ТЗ 2.0 §15.2). Адаптеры читают их без изменения.
var TS2_LEGACY_MAP_ = [
  ['Блюда', 'DISHES', 0], ['Состав', 'DISH_INGREDIENTS', 0], ['ТТК_Версии', 'DISH_VERSIONS', 0], ['Продукты_ID_V53', 'PRODUCTS', 0], ['Продукты_Справочник', 'PRODUCTS', 0],
  ['Поставщики', 'SUPPLIERS', 0], ['Сотрудники', 'EMPLOYEES', 0], ['Производство', 'PRODUCTION_TASKS', 0], ['Склад_Партии', 'STOCK_BATCHES', 0],
  ['Склад_Операции', 'STOCK_OPERATIONS', 0], ['Температуры', 'TEMPERATURE_MEASUREMENTS', 0], ['Температурные_Объекты', 'TEMPERATURE_OBJECTS', 0], ['ППК_V30', 'HACCP_PROGRAMS', 0],
  ['HACCP_ТочкиКонтроля_V30', 'HACCP_CONTROL_POINTS', 0], ['HACCP_Факты_V31', 'HACCP_FACTS', 0], ['Документы', 'DOCUMENTS', 0], ['Audit_Log', 'AUDIT_LOG', 0],
  ['Операции', 'OPERATIONS', 0], ['Факты', 'FACTS', 0], ['TRACE_LINKS', 'TRACE_LINKS', 0], ['Медкнижки', 'MEDICAL_DOCUMENTS', 0], ['ЦС_Договоры', 'CONTRACTS', 0],
  ['ЦС_Нормативы', 'NORMS_REGISTER', 0], ['ЦС_Инструкции_ОТ', 'OT_INSTRUCTIONS', 0], ['ЦС_Должностные', 'JOB_DESCRIPTIONS', 0], ['ЦС_Инструктажи', 'BRIEFINGS', 0],
  ['ЦС_СОУТ', 'SOUT_WORKPLACES', 0], ['ЦС_СИЗ', 'PPE_ISSUANCE', 0], ['ЦС_Акты', 'OCCUPATIONAL_ACTS', 0], ['Оборудование_Реестр', 'EQUIPMENT', 0],
  ['Лаборатория_План', 'LAB_PLANS', 0], ['Лаборатория_Исследования', 'LAB_TESTS', 0], ['Суточные_Пробы', 'DAILY_SAMPLES', 0], ['Журналы_Ожидания', 'JOURNAL_EXPECTATIONS (legacy)', 0]
];

// Коды действий 2.0 (ТЗ 2.0 §8.2) → права текущей ролевой модели (MC_GATE_NEED_). Права ссылаются на коды, а не на экраны.
var TS2_ACTIONS_ = {
  'enterprise.view': '*', 'enterprise.edit': 'org_edit', 'employee.view': 'personnel', 'employee.edit': 'personnel', 'role.assign': 'grants',
  'ttk.view': 'catalog', 'ttk.create': 'ttk_edit', 'ttk.edit': 'ttk_edit', 'ttk.submit': 'ttk_edit', 'ttk.approve': 'ttk_approve', 'ttk.archive': 'ttk_approve',
  'production.plan': 'plan_edit', 'production.execute': 'kanban', 'stock.view': 'stock_view', 'stock.receive': 'receiving', 'stock.writeoff': 'stock',
  'haccp.view': 'haccp_view', 'haccp.record': 'journals', 'haccp.approve': 'haccp_approve', 'reconciliation.view': 'haccp_view|org_edit',
  'reconciliation.approve': 'haccp_approve|org_edit', 'reconciliation.apply': 'org_edit', 'document.upload': 'documents', 'document.approve': 'haccp_approve|org_edit',
  'contract.view': 'documents_view', 'contract.edit': 'documents', 'report.export': 'reports', 'backup.create': 'archive', 'backup.restore': 'system'
};
