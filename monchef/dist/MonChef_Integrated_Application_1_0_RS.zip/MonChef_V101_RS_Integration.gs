/**
 * MON CHEF V101 — Restaurant Service, этап 9: связи с остальными модулями MON CHEF.
 *
 * Собственность Слепцова Дениса Владимировича.
 * Разработчик кода — Слепцов Денис Владимирович.
 *
 * 1. Банкеты ↔ брони зала. Банкет (раздел «Банкеты»), у которого «Место» — название зала, становится бронью этого зала
 *    на все его действующие столы (лист «Бронирования_V1», колонка «Банкет» = номер банкета). Дальше работает обычная
 *    проверка пересечений броней: стол, занятый банкетом, не забронировать, и наоборот. Если банкет лёг поверх уже
 *    принятых броней — бронь банкета всё равно записывается (банкет согласован в своём разделе), а администратору
 *    и директору приходит уведомление со списком пересечений; в «Зал → Брони» они видны красным.
 *    Банкет без подходящего зала можно привязать вручную: «Зал → Брони → Банкеты → Привязать к залу» (столы, время).
 *    Ручная привязка сохраняется при следующих правках банкета; дата, время, гости и отмена всегда берутся из банкета.
 *    Время банкета: «18:00» → 5 часов; «18:00–23:00» → по времени; без времени — весь день (10:00–22:00).
 */

var MC_RS_BANQ_MIN_ = 300;           // длительность банкета, если в банкете указано только начало
var MC_RS_BANQ_DAY_ = ['10:00', 720]; // банкет без времени — весь день

function _rsNorm_(s) { return String(s || '').toLowerCase().replace(/ё/g, 'е').replace(/[^a-zа-я0-9]+/g, ' ').trim(); }
/** Зал по полю «Место» банкета: совпадение названия целиком или словами (самое длинное название). */
function _rsBanqHall_(place, halls) {
  var p = ' ' + _rsNorm_(place) + ' ', best = null, bl = 0;
  if (!p.trim()) return null;
  halls.forEach(function (h) {
    if (h.status !== 'ACTIVE') return;
    var n = _rsNorm_(h.name); if (n.length < 2) return;
    if (p.indexOf(' ' + n + ' ') >= 0 && n.length > bl) { best = h; bl = n.length; }
  });
  return best;
}
/** Время банкета: «18:00», «18.00», «18:00–23:00», «с 18 до 23» → {start, duration}. */
function _rsBanqTime_(t) {
  var m = String(t || '').match(/(\d{1,2})(?:[:.](\d{2}))?/g) || [];
  var hm = m.map(function (x) { var q = /^(\d{1,2})(?:[:.](\d{2}))?$/.exec(x); return q && +q[1] < 24 ? ('0' + q[1]).slice(-2) + ':' + (q[2] || '00') : ''; }).filter(Boolean);
  if (!hm.length || !/\d/.test(String(t || ''))) return { start: MC_RS_BANQ_DAY_[0], duration: MC_RS_BANQ_DAY_[1], allDay: true };
  var a = _rsAbsMin_('2000-01-01', hm[0]), b = hm[1] ? _rsAbsMin_('2000-01-01', hm[1]) : NaN;
  var dur = !isNaN(b) ? (b > a ? b - a : b + 1440 - a) : MC_RS_BANQ_MIN_;
  return { start: hm[0], duration: Math.max(30, Math.min(dur, 1440)) };
}
function _rsBanqCancelled_(e) { return !e || /отмен|cancel/i.test(String(e.status || '')); }
function _rsBanqList_() { try { return JSON.parse(getEvents()) || []; } catch (e) { return []; } }

/** Бронь банкета по данным банкета. cur — действующая бронь банкета (если есть), hall/tables — куда. */
function _rsBanqRow_(e, cur, siteId, hallId, tables, tm, who) {
  var day = _rsDay_(e.date), a = _rsAbsMin_(day, tm.start);
  var f = { siteId: siteId, hallId: hallId, tables: tables, guest: ('Банкет: ' + String(e.format || e.name || 'Банкет')).slice(0, 80), phone: '',
    date: day, start: tm.start, duration: tm.duration, startAbs: a, endAbs: a + tm.duration, guests: Math.max(1, parseInt(e.guests, 10) || 1),
    wishes: '', comment: ('Банкет ' + e.id + (e.contact ? ' · контакт: ' + e.contact : '')).slice(0, 500), manager: cur ? cur['Менеджер'] : who };
  var st = cur && ['ARRIVED', 'SEATED', 'CLOSED'].indexOf(String(cur['Статус'])) >= 0 ? String(cur['Статус']) : 'CONFIRMED';
  var o = cur ? _rsCopy_(cur) : { BookingID: _rsId_('BK'), IdempotencyKey: 'BANQ-' + e.id };
  delete o._row; _rsBkRow_(o, f, st); o['Банкет'] = String(e.id);
  return o;
}
var MC_RS_BANQ_KEYS_ = ['HallID', 'Столы', 'Гость', 'Дата', 'Начало', 'Длительность, мин', 'Гостей', 'Комментарий', 'Статус'];
function _rsBanqSame_(a, b) { return MC_RS_BANQ_KEYS_.every(function (k) { return String(_rsIsDate_(a[k]) ? _rsDay_(a[k]) : a[k]) === String(_rsIsDate_(b[k]) ? _rsDay_(b[k]) : b[k]); }); }

/**
 * Синхронизация банкета с бронями зала. Зовут saveEvent и deleteEvent (Code.gs) после записи банкета; e === null — банкет удалён.
 * Возвращает {bookingId, conflicts[]} или {linked:false}.
 */
function _rsBanquetSync_(eventId, e, op) {
  var s = op && op.session, who = _rsWho_(s);
  var res = _withLock_(function () {
    var rows = _rsRows_(MC_RS_SH_.BOOKINGS), cur = rows.filter(function (r) { return String(r['Банкет']) === String(eventId) && MC_RS_BK_FINAL_.indexOf(String(r['Статус'])) < 0; })[0];
    var plan = [], eop = op || { id: _rsId_('OP') };
    if (_rsBanqCancelled_(e)) {
      if (!cur) return { linked: false };
      var c = _rsCopy_(cur); delete c._row; c['Статус'] = 'CANCELLED'; c['Причина'] = e ? 'Банкет отменён' : 'Банкет удалён'; _rsStamp_(c, s, eop, false);
      plan.push({ sheet: MC_RS_SH_.BOOKINGS, row: c }, { sheet: MC_RS_SH_.EVENTS, row: _rsEventRow_(eop, s, 'BOOKING', c.BookingID, { booking: c.BookingID }, 'BANQUET_RELEASED', { status: cur['Статус'] }, { status: 'CANCELLED', banquet: eventId }) });
      _rsTxApply_(eop, 'RS_BANQUET_SYNC', plan);
      return { bookingId: c.BookingID, released: true, conflicts: [] };
    }
    if (!_rsDay_(e.date)) return { linked: false };
    var halls = _rsRows_(MC_RS_SH_.HALLS).map(_rsHallObj_), tidx = _rsTablesIdx_(), hall = _rsBanqHall_(e.place, halls), tables, siteId, hallId;
    if (hall && (!cur || String(cur.HallID) !== hall.id)) {   // зал по «Месту»: все действующие столы зала
      tables = Object.keys(tidx).filter(function (t) { return tidx[t].hallId === hall.id && tidx[t].status === 'ACTIVE'; });
      siteId = hall.siteId; hallId = hall.id;
    } else if (cur) { tables = _rsJ_(cur['Столы'], []) || []; siteId = String(cur.SiteID); hallId = String(cur.HallID); }   // ручная привязка сохраняется
    else return { linked: false };
    if (!tables.length) return { linked: false };
    var tm = cur && !hall ? { start: _rsBanqTime_(e.time).allDay && _rsHm_(cur['Начало']) ? _rsHm_(cur['Начало']) : _rsBanqTime_(e.time).start,
      duration: _rsBanqTime_(e.time).allDay ? (parseInt(cur['Длительность, мин'], 10) || MC_RS_BANQ_DAY_[1]) : _rsBanqTime_(e.time).duration } : _rsBanqTime_(e.time);
    var o = _rsBanqRow_(e, cur, siteId, hallId, tables, tm, who);
    var b = _rsBkObj_(o), all = _rsBookingsBetween_(siteId, b.startAbs - 1440, b.endAbs + 1440);
    var conflicts = _rsBkConflicts_(all, tables, b.startAbs, b.endAbs, b.id).map(function (x) {
      return { id: x.id, guest: x.guest, date: x.date, start: x.start, end: x.end, tables: x.tables.filter(function (t) { return tables.indexOf(t) >= 0; }).map(function (t) { return tidx[t] ? tidx[t].number : t; }) };
    });
    if (cur && _rsBanqSame_(cur, o)) return { bookingId: b.id, conflicts: conflicts, unchanged: true };
    _rsStamp_(o, s, eop, !cur);
    plan.push({ sheet: MC_RS_SH_.BOOKINGS, row: o }, { sheet: MC_RS_SH_.EVENTS, row: _rsEventRow_(eop, s, 'BOOKING', b.id, { booking: b.id }, cur ? 'BANQUET_UPDATED' : 'BANQUET_LINKED', null,
      { banquet: eventId, date: b.date, start: b.start, end: b.end, tables: tables.length, conflicts: conflicts.length }) });
    _rsTxApply_(eop, 'RS_BANQUET_SYNC', plan);
    if (conflicts.length) {
      var txt = conflicts.map(function (x) { return x.guest + ' ' + x.date.split('-').reverse().join('.') + ' ' + x.start + '–' + x.end + ', стол ' + x.tables.join(', '); }).join('; ');
      ['Администратор', 'Директор'].forEach(function (role) {
        try { _notify_('RS_BANQUET', 'warning', 'Банкет «' + String(e.format || 'Банкет') + '» ' + b.date.split('-').reverse().join('.') + ' пересекается с бронями зала', txt + '. Перенесите брони или банкет.', role, 'RS_BQ_' + eventId + '_' + b.date + '_' + role, eop); } catch (x) {}
      });
    }
    return { bookingId: b.id, conflicts: conflicts };
  });
  try { if (op && typeof _audit_ === 'function' && res && res.bookingId && !res.unchanged) _audit_(op, 'RS_BANQUET_SYNC', MC_RS_SH_.BOOKINGS, res.bookingId, null, { banquet: eventId, released: !!res.released, conflicts: (res.conflicts || []).length }); } catch (x) {}
  return res;
}

/** Банкеты периода и их связь с залом: {from, to} (по умолчанию — 31 день от сегодня). */
function rsBanquetList(json, token) {
  return _rsRead_(token, 'hall_view|booking|hall_manage', function (s) {
    var d = _rsJ_(json, {}) || {}, from = _rsDay_(d.from) || _rsToday_(), to = _rsDay_(d.to) || _rsFromAbs_(_rsAbsMin_(from, '00:00') + 31 * 1440).day;
    var halls = _rsRows_(MC_RS_SH_.HALLS).map(_rsHallObj_), hidx = {}, tidx = _rsTablesIdx_();
    halls.forEach(function (h) { hidx[h.id] = h; });
    var bks = _rsRows_(MC_RS_SH_.BOOKINGS).map(_rsBkObj_), act = bks.filter(function (b) { return MC_RS_BK_FINAL_.indexOf(b.status) < 0; });
    var out = _rsBanqList_().filter(function (e) { var day = _rsDay_(e.date); return day && day >= from && day <= to && !_rsBanqCancelled_(e); }).map(function (e) {
      var bk = act.filter(function (b) { return b.eventId === String(e.id); })[0], tm = _rsBanqTime_(e.time), cf = [];
      if (bk) cf = _rsBkConflicts_(act, bk.tables, bk.startAbs, bk.endAbs, bk.id).map(function (x) { return { guest: x.guest, start: x.start, end: x.end, tables: x.tables.filter(function (t) { return bk.tables.indexOf(t) >= 0; }).map(function (t) { return tidx[t] ? tidx[t].number : t; }) }; });
      return { id: String(e.id), date: _rsDay_(e.date), time: String(e.time || ''), start: tm.start, duration: tm.duration, allDay: !!tm.allDay, format: String(e.format || e.name || 'Банкет'),
        guests: parseInt(e.guests, 10) || 0, place: String(e.place || ''), suggestedHall: (_rsBanqHall_(e.place, halls) || {}).id || '',
        booking: bk ? { id: bk.id, version: bk.version, hallId: bk.hallId, hall: hidx[bk.hallId] ? hidx[bk.hallId].name : '', tables: bk.tables, tableNumbers: bk.tables.map(function (t) { return tidx[t] ? tidx[t].number : t; }),
          start: bk.start, end: bk.end, status: bk.status } : null, conflicts: cf };
    }).sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : a.start < b.start ? -1 : 1; });
    return { from: from, to: to, banquets: out, can: { link: _mcRbHasExact_(s, 'booking') } };
  });
}

/** Привязать банкет к залу вручную: {idem, eventId, tables[], start?, duration?, force?}. tables [] — отвязать. Пересечения — только с force. */
function rsBanquetLink(json, token) {
  return _rsMutate_(token, 'booking', 'RS_BANQUET_LINK', json, function (c) {
    var d = c.d, e = _rsBanqList_().filter(function (x) { return String(x.id) === String(d.eventId); })[0];
    if (!e || _rsBanqCancelled_(e)) return { fail: ['NOT_FOUND', 'Банкет не найден или отменён'] };
    var rows = _rsRows_(MC_RS_SH_.BOOKINGS), cur = rows.filter(function (r) { return String(r['Банкет']) === String(e.id) && MC_RS_BK_FINAL_.indexOf(String(r['Статус'])) < 0; })[0];
    var tables = (Array.isArray(d.tables) ? d.tables : []).map(String).filter(function (t, i, a) { return t && a.indexOf(t) === i; });
    if (!tables.length) {
      if (!cur) return { data: { unlinked: true } };
      var u = _rsCopy_(cur); delete u._row; u['Статус'] = 'CANCELLED'; u['Причина'] = 'Банкет отвязан от зала'; _rsStamp_(u, c.s, c.op, false);
      return { data: { unlinked: true }, plan: [{ sheet: MC_RS_SH_.BOOKINGS, row: u }, { sheet: MC_RS_SH_.EVENTS, row: _rsEventRow_(c.op, c.s, 'BOOKING', u.BookingID, { booking: u.BookingID }, 'BANQUET_UNLINKED', null, { banquet: e.id }) }],
        audit: { action: 'RS_BANQUET_UNLINKED', entity: MC_RS_SH_.BOOKINGS, id: u.BookingID, after: { banquet: e.id } } };
    }
    var tidx = _rsTablesIdx_(), hidx = _rsHallsIdx_(), hallId = '';
    for (var i = 0; i < tables.length; i++) {
      var t = tidx[tables[i]]; if (!t || t.status !== 'ACTIVE') return { fail: ['VALIDATION', 'Стол не найден или в архиве'] };
      if (!hidx[t.hallId] || hidx[t.hallId].status !== 'ACTIVE') return { fail: ['VALIDATION', 'Зал стола № ' + t.number + ' в архиве'] };
      if (hallId && hallId !== t.hallId) return { fail: ['VALIDATION', 'Столы банкета — в одном зале'] }; hallId = t.hallId;
    }
    var tm = _rsBanqTime_(e.time), st = _rsHm_(d.start), dur = parseInt(d.duration, 10);
    if (st) tm = { start: st, duration: dur >= 30 && dur <= 1440 ? dur : tm.duration };
    var o = _rsBanqRow_(e, cur, tidx[tables[0]].siteId, hallId, tables, tm, _rsWho_(c.s)), b = _rsBkObj_(o);
    var all = _rsBookingsBetween_(b.siteId, b.startAbs - 1440, b.endAbs + 1440), cf = _rsBkConflicts_(all, tables, b.startAbs, b.endAbs, b.id);
    if (cf.length && !d.force) return { fail: ['CONFLICT', 'Пересекается с бронями: ' + cf.map(function (x) { return x.guest + ' ' + x.start + '–' + x.end + ', стол ' + x.tables.filter(function (t) { return tables.indexOf(t) >= 0; }).map(function (t) { return tidx[t] ? tidx[t].number : t; }).join(', '); }).join('; ') + '. Перенесите брони или привяжите банкет «несмотря на пересечения»'] };
    _rsStamp_(o, c.s, c.op, !cur);
    return { data: { bookingId: b.id, conflicts: cf.length }, plan: [{ sheet: MC_RS_SH_.BOOKINGS, row: o }, { sheet: MC_RS_SH_.EVENTS, row: _rsEventRow_(c.op, c.s, 'BOOKING', b.id, { booking: b.id }, 'BANQUET_LINKED', null, { banquet: e.id, tables: tables.length, start: b.start, end: b.end, conflicts: cf.length, manual: true }) }],
      audit: { action: 'RS_BANQUET_LINKED', entity: MC_RS_SH_.BOOKINGS, id: b.id, after: { banquet: e.id, tables: tables, start: b.start, duration: b.duration, conflicts: cf.length } } };
  });
}

MC_GATE_EXT_.rsBanquetList = { need: 'hall_view|booking|hall_manage' };
MC_GATE_EXT_.rsBanquetLink = { need: 'booking', mut: true };

/*
 * 2. Предзаказы → закупки и план производства. Подтверждённые предзаказы броней недели входят в недельный оперативный план
 *    MON CHEF (V14) как отдельный источник спроса («PREORDER»): сырьё — в закупку (заявки поставщикам V21 строятся из плана),
 *    нехватка п/ф — в задания производства и канбан. Сами блюда предзаказа заданиями «изготовить заранее» не становятся:
 *    их готовят по заказу на экране кухни и бара (этапы 3–6). Склад предзаказ не резервирует и не списывает.
 */
/** Порции позиции предзаказа: порц/шт — количество; г/кг/мл/л — вес ÷ выход блюда. */
function _rsPoPortions_(it, dish) {
  var u = String(it.unit || 'порц').toLowerCase().replace(/\./g, ''), q = Number(it.qty) || 0;
  if (/^(г|кг|мл|л)$/.test(u)) { var base = q * (u === 'кг' || u === 'л' ? 1000 : 1), y = Number(dish && dish.yield) || 0; return y > 0 ? base / y : 0; }
  return q;
}
/** Спрос подтверждённых предзаказов за период [from; to] (даты YYYY-MM-DD) в форме банкета для планирования: {id, date, time, format, items[{code, qty}], source}. */
function _rsPreorderDemand_(from, to) {
  var pos = {}, out = [], idx = null;
  try { idx = _buildDishIndexes_(); } catch (e) { idx = { dishByCode: {} }; }
  _rsRows_(MC_RS_SH_.PREORDERS).forEach(function (r) { pos[String(r.PreorderID)] = _rsPoObj_(r); });
  _rsRows_(MC_RS_SH_.BOOKINGS).map(_rsBkObj_).forEach(function (bk) {
    if (bk.date < from || bk.date > to || ['NEW', 'CONFIRMED', 'ARRIVED', 'SEATED'].indexOf(bk.status) < 0) return;
    var po = pos[bk.preorderId]; if (!po || po.status !== 'CONFIRMED') return;
    var items = po.items.map(function (it) { return { code: it.code, name: it.name, qty: Math.round(_rsPoPortions_(it, idx.dishByCode[it.code]) * 1000) / 1000 }; }).filter(function (x) { return x.qty > 0; });
    if (items.length) out.push({ id: 'PO:' + po.id, date: bk.date, time: bk.start, format: 'Предзаказ: ' + bk.guest, name: 'Предзаказ: ' + bk.guest, guests: bk.guests, items: items, status: 'Подтверждён', source: 'PREORDER', bookingId: bk.id });
  });
  return out;
}

/*
 * 3. Stop/Go по остаткам. Система проверяет, хватит ли партий на СЛЕДУЮЩУЮ порцию (тем же движком V71 без списания, что и
 *    при «Готовить»): после каждого «Готово» — для этого блюда, раз в час и по кнопке — для всего меню (блюда с ценой на сегодня).
 *    Не хватает — ПРЕДЛОЖЕНИЕ «поставить STOP» на экране Stop/Go (и уведомление шеф-повару / менеджеру бара). Ставит STOP
 *    человек одним нажатием: причина «Закончилось сырьё», принятые заказы сохраняются. Сам STOP система не ставит —
 *    остаток мог не дойти до учёта (приход не оформлен), решение за кухней. Сырьё снова есть, а блюдо на STOP «Закончилось
 *    сырьё» — предложение вернуть GO (GO — как обычно, с проверкой «продукты есть, оборудование работает, качество в норме»).
 *    Предложение, ставшее неактуальным (приход, ревизия), закрывается само.
 */
MC_RS_SH_.STOPSUG = 'СтопГО_Предложения_V1';
MC_RS_HEAD_[MC_RS_SH_.STOPSUG] = ['SuggID', 'DishCode', 'Название', 'Подразделение', 'Предложение', 'Нехватка', 'Статус', 'Создано', 'Решил', 'Решено', 'Комментарий'].concat(MC_RS_STD_);
var MC_RS_SUG_RU_ = { STOP: 'поставить STOP', GO: 'вернуть GO' };

/** Хватит ли партий на одну порцию: {code: {short: [{product, qty, unit}], noTtk}}. Один снимок склада на всю серию. */
function _rsStockGap_(codes) {
  var idx = _buildDishIndexes_(), out = {}, sn = { v: _stockBatchesSheet_().getDataRange().getValues(), res: _v71Reserved_(), blocked: _v71Blocked_() };
  codes.forEach(function (code) {
    var dish = idx.dishByCode[code];
    if (!dish || !dish.ing || !dish.ing.length) { out[code] = { short: [], noTtk: true }; return; }
    try {
      var r = _v71Run_({ kind: 'DISH', name: String(dish.name), code: String(dish.code), dish: dish, unit: 'порц.' }, 1, { at: new Date(), dry: true, snap: sn, idx: idx });
      out[code] = { short: (r.short || []).map(function (x) { return { product: x.product, qty: Math.round(x.qty * 1000) / 1000, unit: x.unit }; }) };
    } catch (e) { out[code] = { short: [], error: String(e && e.message || e) }; }
  });
  return out;
}
function _rsSugObj_(r) {
  return { id: String(r.SuggID), code: String(r.DishCode), name: String(r['Название'] || ''), dept: String(r['Подразделение']), kind: String(r['Предложение']), kindRu: MC_RS_SUG_RU_[r['Предложение']] || r['Предложение'],
    short: _rsJ_(r['Нехватка'], []) || [], status: String(r['Статус']), at: _rsIsDate_(r['Создано']) ? Utilities.formatDate(r['Создано'], _mcTz_(), 'dd.MM HH:mm') : '', version: parseInt(r.Version, 10) || 1 };
}
/**
 * Проверка остатков и предложения Stop/Go. codes — блюда (null — всё меню на сегодня). s, op — кто запустил (null — расписание).
 * Возвращает {checked, opened[], closed[]}.
 */
function _rsStopWatch_(codes, s, op) {
  var dishes = _rsDishes_();
  if (!codes) { var pi = {}; try { pi = _rsPriceIdx_(_rsToday_()); } catch (e) { pi = {}; } codes = Object.keys(pi).filter(function (c) { return dishes[c]; }); }
  codes = codes.filter(function (c, i, a) { return dishes[c] && a.indexOf(c) === i; });
  if (!codes.length) return { checked: 0, opened: [], closed: [] };
  var gap = _rsStockGap_(codes), eop = op || { id: _rsId_('OP') }, opened = [], closed = [];
  _withLock_(function () {
    var stops = _rsStopRows_(), sugs = _rsRows_(MC_RS_SH_.STOPSUG), plan = [], now = new Date();
    var open = function (code, dept, kind) { return sugs.filter(function (r) { return String(r.DishCode) === code && String(r['Подразделение']) === dept && String(r['Предложение']) === kind && String(r['Статус']) === 'OPEN'; })[0]; };
    var close = function (r, why) { var o = _rsCopy_(r); delete o._row; o['Статус'] = 'CLOSED'; o['Решено'] = now; o['Решил'] = 'система'; o['Комментарий'] = why; _rsStamp_(o, s, eop, false); plan.push({ sheet: MC_RS_SH_.STOPSUG, row: o }); closed.push(_rsSugObj_(o)); };
    codes.forEach(function (code) {
      var g = gap[code]; if (!g || g.noTtk || g.error) return;
      var dept = dishes[code].dept === 'BAR' ? 'BAR' : 'KITCHEN', cur = _rsStopCur_(stops, code, dept), st = cur ? String(cur['Статус']) : 'GO', lack = g.short.length > 0;
      var sStop = open(code, dept, 'STOP'), sGo = open(code, dept, 'GO');
      if (lack && (st === 'GO' || st === 'LIMITED') && !sStop) {
        var row = _rsStamp_({ SuggID: _rsId_('SUG'), DishCode: code, 'Название': dishes[code].name, 'Подразделение': dept, 'Предложение': 'STOP', 'Нехватка': JSON.stringify(g.short), 'Статус': 'OPEN', 'Создано': now }, s, eop, true);
        plan.push({ sheet: MC_RS_SH_.STOPSUG, row: row }); opened.push(_rsSugObj_(row));
        try { _notify_('RS_STOP_SUGGEST', 'warning', 'Не хватит на следующую порцию: ' + dishes[code].name + (dept === 'BAR' ? ' (бар)' : ''), 'Нет: ' + g.short.map(function (x) { return x.product + ' ' + x.qty + ' ' + x.unit; }).join(', ') + '. Поставьте STOP на экране «Кухня и бар → Stop/Go» или оформите приход.', dept === 'BAR' ? 'Менеджер бара' : 'Шеф-повар', 'RS_SUG_' + row.SuggID, eop); } catch (e) {}
      }
      if (!lack && sStop) close(sStop, 'сырьё есть');
      if (lack && sGo) close(sGo, 'сырья снова нет');
      if (!lack && st === 'STOP' && String(cur['Причина']) === 'Закончилось сырьё' && !sGo) {
        var rg = _rsStamp_({ SuggID: _rsId_('SUG'), DishCode: code, 'Название': dishes[code].name, 'Подразделение': dept, 'Предложение': 'GO', 'Нехватка': '[]', 'Статус': 'OPEN', 'Создано': now }, s, eop, true);
        plan.push({ sheet: MC_RS_SH_.STOPSUG, row: rg }); opened.push(_rsSugObj_(rg));
        try { _notify_('RS_GO_SUGGEST', 'info', 'Сырьё есть: ' + dishes[code].name + ' можно вернуть в GO', 'Проверьте и верните GO на экране «Кухня и бар → Stop/Go».', dept === 'BAR' ? 'Менеджер бара' : 'Шеф-повар', 'RS_SUG_' + rg.SuggID, eop); } catch (e) {}
      }
    });
    if (plan.length) _rsTxApply_(eop, 'RS_STOP_WATCH', plan);
  });
  return { checked: codes.length, opened: opened, closed: closed };
}
/** Предложения Stop/Go (открытые) для экрана: {dept}. */
function rsStopSuggestions(json, token) {
  return _rsRead_(token, 'stopgo_view|stopgo_kitchen|stopgo_bar|stopgo_approve|kitchen_queue|bar_queue', function () {
    var d = _rsJ_(json, {}) || {}, dept = d.dept === 'BAR' ? 'BAR' : d.dept === 'KITCHEN' ? 'KITCHEN' : '';
    return { suggestions: _rsRows_(MC_RS_SH_.STOPSUG).map(_rsSugObj_).filter(function (x) { return x.status === 'OPEN' && (!dept || x.dept === dept); }) };
  });
}
/** Проверить остатки сейчас (всё меню на сегодня). */
function rsStopWatchRun(json, token) {
  var s; try { s = _requireAuth_(token, null); } catch (e) { return _failFrom_(e); }
  if (!_mcRbHasExact_(s, 'stopgo_kitchen|stopgo_bar|stopgo_approve')) return _mcRbDenyJson_('Проверка остатков — кухне и бару (Stop/Go).');
  try { var r = _rsStopWatch_(null, s, null); return _ok_(r); } catch (e) { return _rsFail_(e, null); }
}
/** Решение по предложению: {idem, id, version, accept, affected: KEEP|PROBLEM}. STOP — ставится с причиной «Закончилось сырьё»; GO — только отклонить (GO возвращается обычной кнопкой). */
function rsStopSuggestDecide(json, token) {
  var d = _rsJ_(json, {}) || {}, row = _rsRows_(MC_RS_SH_.STOPSUG).filter(function (r) { return String(r.SuggID) === String(d.id); })[0];
  if (!row) return _fail_('NOT_FOUND', 'Предложение не найдено');
  var sg = _rsSugObj_(row), stopRes = null;
  if (d.accept && sg.kind === 'STOP') {
    stopRes = JSON.parse(rsStopSet(JSON.stringify({ idem: String(d.idem || '') + '-stop', code: sg.code, dept: sg.dept, status: 'STOP', reason: 'Закончилось сырьё',
      comment: 'По остаткам: нет ' + sg.short.map(function (x) { return x.product + ' ' + x.qty + ' ' + x.unit; }).join(', '), affected: d.affected === 'PROBLEM' ? 'PROBLEM' : 'KEEP' }), token));
    if (!stopRes.success) return JSON.stringify(stopRes);
  }
  return _rsMutate_(token, _rsStopNeed_(sg.dept) + '|stopgo_approve', 'RS_STOP_SUGGEST', json, function (c) {
    var r = _rsRows_(MC_RS_SH_.STOPSUG).filter(function (x) { return String(x.SuggID) === sg.id; })[0];
    if (String(r['Статус']) !== 'OPEN') return { fail: ['VALIDATION', 'Предложение уже закрыто'] };
    var o = _rsCopy_(r); delete o._row; o['Статус'] = c.d.accept && sg.kind === 'STOP' ? 'APPLIED' : 'DISMISSED'; o['Решено'] = new Date(); o['Решил'] = _rsWho_(c.s);
    o['Комментарий'] = _rsS_(c.d.comment).slice(0, 300); _rsStamp_(o, c.s, c.op, false);
    return { data: { status: o['Статус'], stop: stopRes ? stopRes.data : null }, plan: [{ sheet: MC_RS_SH_.STOPSUG, row: o }],
      audit: { action: 'RS_STOP_SUGGEST_' + o['Статус'], entity: MC_RS_SH_.STOPSUG, id: sg.id, after: { code: sg.code, dept: sg.dept, kind: sg.kind, status: o['Статус'] } } };
  });
}
/** Расписание: раз в час — проверка всего меню. */
function rsStopWatchTick_() { try { return _rsStopWatch_(null, null, null); } catch (e) { try { _log_('WARN', 'Stop/Go по остаткам: ' + e); } catch (x) {} return null; } }
(function () { try { if (!MC_SCHEDULE.some(function (j) { return j.fn === 'rsStopWatchTick_'; })) MC_SCHEDULE.push({ fn: 'rsStopWatchTick_', everyMin: 60 }); } catch (e) {} })();

MC_GATE_EXT_.rsStopSuggestions = { need: 'stopgo_view|stopgo_kitchen|stopgo_bar|stopgo_approve|kitchen_queue|bar_queue' };
MC_GATE_EXT_.rsStopWatchRun = { need: 'stopgo_kitchen|stopgo_bar|stopgo_approve' };   // повтор безопасен: открытые предложения не дублируются
MC_GATE_EXT_.rsStopSuggestDecide = { need: 'stopgo_kitchen|stopgo_bar|stopgo_approve', mut: true };

/*
 * 4. ХАССП у плиты.
 *  а) ККТ при «Готово». Блюду (ТТК) назначены обязательные ККТ (лист «ТТК_ККТ», как для выпуска п/ф, §9) — на карточке
 *     задания кухни и бара поля замера; замер — обычный факт HACCP (V31) с привязкой к номеру задания (RelatedBatchID).
 *     «Готово» блокируется, пока нет замера по каждой ККТ в пределах; замер вне предела — корректирующее действие и повторный
 *     замер. Тепловые ККТ (термообработка, t° в толще, охлаждение, разогрев, фритюр) вносит горячий цех / шеф / су-шеф
 *     (кондитер — свою выпечку), как в производстве. Значения вносит человек; система их не подставляет.
 *  б) Бракераж (V77 «бракераж по продажам»). Блюда, приготовленные кухней по заказам зала («Готово» сегодня), попадают
 *     в список «Продано без бракеража» сразу, а не после закрытия заказа; продажа зала при закрытии второй раз не считается.
 */
function _rsCcpAssign_() {
  var sh = null; try { sh = _book_().getSheetByName(MC_TCCP_SHEET_); } catch (e) {}
  if (!sh || sh.getLastRow() < 2) return {};
  var v = sh.getDataRange().getValues(), last = {}, out = {};
  for (var i = 1; i < v.length; i++) last[String(v[i][0]) + '|' + String(v[i][1])] = String(v[i][2]);
  Object.keys(last).forEach(function (k) { if (last[k] !== 'ACTIVE') return; var p = k.split('|'); (out[p[0]] = out[p[0]] || []).push(p[1]); });
  return out;
}
/** Карточкам заданий (в работе) — ККТ и их состояние: t.ccp = {items[], ok}. Один проход по листам. */
function _rsCcpAttach_(list) {
  var asg = _rsCcpAssign_(), act = list.filter(function (t) { return asg[t.code] && ['ACCEPTED', 'COOKING', 'PROBLEM', 'NEW'].indexOf(t.status) >= 0; });
  if (!act.length) return;
  var ctl = _tccpActiveControls_(), ids = {}, facts = [];
  act.forEach(function (t) { ids[t.id] = 1; });
  try { facts = _v31Rows_(MC_V31.FACT).filter(function (r) { return ids[String(r[13])]; }); } catch (e) {}
  act.forEach(function (t) {
    var items = asg[t.code].map(function (cid) {
      var c = ctl[cid] || { id: cid, point: cid, inactive: true }, f = facts.filter(function (r) { return String(r[13]) === t.id && String(r[1]) === cid; }).slice(-1)[0];
      var st = c.inactive ? 'INACTIVE' : !f ? 'MISSING' : String(f[7]) === 'OK' ? 'OK' : 'DEVIATION';
      return { controlId: cid, point: c.point, limit: c.limit || '', unit: c.unit || '', min: c.min, max: c.max, status: st, value: f ? f[5] : '', thermal: MC_RB_HOT_CCP_RE_.test(String(c.point || '') + ' ' + String(c.parameter || '')) };
    });
    t.ccp = { items: items, ok: items.every(function (x) { return x.status === 'OK'; }) };
  });
}
/** Можно ли «Готово»: ККТ блюда выполнены по этому заданию. */
function _rsCcpGate_(code, ticketId) {
  if (!(_rsCcpAssign_()[code] || []).length) return { ok: true };
  return _tccpState_(code, ticketId);
}
/** Замер ККТ по заданию кухни/бара: {ticketId, controlId, value, correctiveAction?, equipmentId?}. */
function rsTicketCcp(json, token) {
  var s; try { s = _requireAuth_(token, null); } catch (e) { return _failFrom_(e); }
  try {
    var d = _rsJ_(json, {}) || {}, row = _rsRows_(MC_RS_SH_.QUEUE).filter(function (r) { return String(r.TicketID) === String(d.ticketId); })[0];
    if (!row) return _fail_('NOT_FOUND', 'Задание не найдено');
    var dept = String(row['Подразделение']), code = String(row.DishCode);
    if (!_mcRbHasExact_(s, dept === 'BAR' ? 'bar_queue' : 'kitchen_queue') || (typeof _rsCanTicket_ === 'function' && !_rsCanTicket_(s, row))) return _mcRbDenyJson_('Задание другого цеха или подразделения.');
    if (['NEW', 'ACCEPTED', 'COOKING', 'PROBLEM'].indexOf(String(row['Статус'])) < 0) return _fail_('VALIDATION', 'Замер вносится, пока блюдо готовится');
    var ctl = _tccpFor_(code).filter(function (x) { return x.id === String(d.controlId); })[0];
    if (!ctl) return _fail_('VALIDATION', 'Эта ККТ не назначена блюду «' + row['Название'] + '»');
    if (dept !== 'BAR' && MC_RB_HOT_CCP_RE_.test(String(ctl.point || '') + ' ' + String(ctl.parameter || '')) && !_mcRbHasExact_(s, 'hot_ccp') && !(_mcRbHasExact_(s, 'shop_pastry') && /кондитер/i.test(String(row['Цех'] || '')))) {
      _mcRbAuditDenied_(s, 'rsTicketCcp', 'hot_ccp', String(row.TicketID));
      return _mcRbDenyJson_('ККТ «' + ctl.point + '» (тепловая обработка, охлаждение, разогрев, фритюр) вносит повар горячего цеха, шеф-повар или су-шеф.');
    }
    var r = v31RecordHaccpFact(JSON.stringify({ controlId: ctl.id, value: d.value, equipmentId: d.equipmentId || '', relatedBatchId: String(row.TicketID),
      object: 'Заказ ' + row.OrderID + ' · стол ' + row['Стол'] + ' · ' + row['Название'], correctiveAction: d.correctiveAction || '' }), token);
    var j = typeof r === 'string' ? JSON.parse(r) : r;
    if (j && (j.success || j.ok)) { j.data = j.data || {}; j.data.state = _tccpState_(code, String(row.TicketID)); try { if (typeof _mcGenBump_ === 'function') _mcGenBump_(); } catch (e) {} }
    return JSON.stringify(j);
  } catch (e) { return _rsFail_(e, null); }
}
/** Номера продаж зала (SL-…) из журнала продаж — чтобы бракераж не считал блюдо второй раз при закрытии заказа. */
function _rsSaleIdSet_() {
  var out = {}, sh = null; try { sh = _book_().getSheetByName('Ж_Продажи'); } catch (e) {}
  if (!sh || sh.getLastRow() < 2) return out;
  sh.getDataRange().getValues().slice(1).forEach(function (r) { r.forEach(function (c) { var m = /RS-ALLOC .*?\b(SL-\d{8}-[0-9A-F]{8})\b/.exec(String(c || '')); if (m) out[m[1]] = 1; }); });
  return out;
}
/** «Продажи под заказ» для бракеража из заданий кухни: «Готово» в периоде, не отменено. Бар (напитки) — нет: бракераж — блюда кухни. */
function _rsBrakSales_(fromDay, toDay) {
  var out = [];
  _rsRows_(MC_RS_SH_.QUEUE).forEach(function (r) {
    if (String(r['Подразделение']) !== 'KITCHEN' || ['READY', 'ISSUED'].indexOf(String(r['Статус'])) < 0 || !_rsIsDate_(r['Готово'])) return;
    var day = Utilities.formatDate(r['Готово'], _mcTz_(), 'yyyy-MM-dd'); if (day < fromDay || day > toDay) return;
    out.push({ day: day, hm: Utilities.formatDate(r['Готово'], _mcTz_(), 'HH:mm'), name: String(r['Название'] || ''), code: String(r.DishCode), qty: _rsNum_(r['Кол-во']) || 1, seller: String(r['Исполнитель'] || '') });
  });
  return out;
}

MC_GATE_EXT_.rsTicketCcp = { need: 'kitchen_queue|bar_queue', mut: true };

/*
 * 5. Отзыв продукции (V74): партия, ушедшая в блюдо зала, показывается с адресатом — стол, заказ, время подачи, официант,
 *    гость брони (имя и телефон, если заказ открыт по брони: по нему можно известить гостя). Блюдо приготовлено, но не подано
 *    (отменено с расходом) — так и написано. Дубль связи «партия → продажа» при закрытии заказа отзыв не считает (V74).
 */
function _rsRecallInfo_(itemId) {
  try {
    var it = _rsRows_(MC_RS_SH_.ITEMS).filter(function (r) { return String(r.OrderItemID) === String(itemId); })[0];
    if (!it) return null;
    var o = _rsRows_(MC_RS_SH_.ORDERS).filter(function (r) { return String(r.OrderID) === String(it.OrderID); })[0] || {};
    var t = _rsTablesIdx_()[String(o.TableID || '')], bk = o.BookingID ? _rsRows_(MC_RS_SH_.BOOKINGS).filter(function (r) { return String(r.BookingID) === String(o.BookingID); })[0] : null;
    var fmt = function (d) { return _rsIsDate_(d) ? Utilities.formatDate(d, _mcTz_(), 'dd.MM.yyyy HH:mm') : ''; };
    var served = _rsIsDate_(it['Подано']), st = String(it['Статус']), when = served ? it['Подано'] : (o['Открыт'] || '');
    var to = 'Гость зала: стол № ' + (t ? t.number : '?') + ', заказ ' + String(it.OrderID).slice(-8) + (st === 'CANCELLED' ? ' — блюдо отменено, гостю не подано' : served ? ', подано ' + fmt(it['Подано']) + (it['Подал'] ? ' (' + it['Подал'] + ')' : '') : ', ' + (MC_RS_IT_RU_ && MC_RS_IT_RU_[st] || st)) +
      (o['Официант'] ? ', официант ' + o['Официант'] : '') + (bk ? ', бронь: ' + String(bk['Гость'] || '') : '');
    return { to: to, what: String(it['Название'] || ''), contact: bk && bk['Телефон'] ? String(bk['Телефон']) : '', need: !!(bk && st !== 'CANCELLED'), at: when, atText: fmt(when) || '' };
  } catch (e) { return null; }
}

/*
 * 6. График смен (V98) ↔ зал, кухня, бар.
 *  • Кто на смене сегодня (из «График_Смен_V98», статус «в графике»): официанты и администраторы зала, кухня, бар — на схеме зала
 *    и на экране кухни и бара; «сейчас» — по часам смены (смена через полночь учитывается).
 *  • Закрепление столов за официантами на день (администратор, «Зал → Смена»): только официанты из графика этого дня
 *    (графика на день нет — любой действующий официант, с предупреждением). Стол закреплён за одним официантом.
 *  • Открытие стола: администратор — заказ сразу на закреплённого официанта (можно выбрать другого из смены);
 *    официант открывает и чужой закреплённый стол (гостей не держим), но видит предупреждение; нет в графике — предупреждение.
 *    Блокировок нет: график — план, а не пропуск в систему (допуск к работе — медкнижки, этап 4).
 */
MC_RS_SH_.TABLEASSIGN = 'Закрепление_Столов_V1';
MC_RS_HEAD_[MC_RS_SH_.TABLEASSIGN] = ['AssignID', 'Дата', 'SiteID', 'WaiterID', 'Официант', 'Столы', 'Статус'].concat(MC_RS_STD_);
var MC_RS_GRP_ = { hall: /официант|администратор|руководитель смены|хостес/i, bar: /бармен|менеджер бара|бариста/i, kitchen: /повар|шеф|кондитер|заготов|мойщ|кухн/i };
function _rsGrp_(role) { role = String(role || ''); return MC_RS_GRP_.bar.test(role) ? 'bar' : MC_RS_GRP_.kitchen.test(role) ? 'kitchen' : MC_RS_GRP_.hall.test(role) ? 'hall' : 'other'; }
/** Смена дня: {has (график на день есть), list[{id, name, role, group, start, end, now}]}. hm — «сейчас» (пусто — весь день). */
function _rsOnShift_(siteId, day, hm) {
  var A = []; try { A = _v98Assigns_(); } catch (e) { return { has: false, list: [] }; }
  var prev = _rsFromAbs_(_rsAbsMin_(day, '00:00') - 1440).day, m = hm ? _v98Min_(hm) : null, out = [], seen = {};
  var has = A.some(function (a) { return a.day === day && a.status !== 'CANCELLED' && (!siteId || a.site === siteId); });
  A.forEach(function (a) {
    if (a.status !== 'PLANNED' || (siteId && a.site !== siteId) || (a.day !== day && a.day !== prev)) return;
    var sp = _v98Span_(a.start, a.end); if (!sp) return;
    if (a.day === prev && sp[1] <= 1440) return;   // вчерашняя смена, не переходящая через полночь
    var now = m === null ? true : a.day === day ? (m >= sp[0] && m < sp[1]) : m < sp[1] - 1440;
    if (a.day === prev && !now) return;
    var k = a.emp + '|' + a.start; if (seen[k]) return; seen[k] = 1;
    out.push({ id: a.emp, name: a.name, role: a.role, group: _rsGrp_(a.role), start: a.start, end: a.end, now: now });
  });
  out.sort(function (x, y) { return x.group < y.group ? -1 : x.group > y.group ? 1 : x.start < y.start ? -1 : 1; });
  return { has: has, list: out };
}
/** Закрепление столов на день: {tableId: {waiterId, waiter, assignId}}. */
function _rsTableAssign_(siteId, day) {
  var out = {};
  _rsRows_(MC_RS_SH_.TABLEASSIGN).forEach(function (r) {
    if (String(r['Статус']) !== 'ACTIVE' || _rsDay_(r['Дата']) !== day || (siteId && String(r.SiteID) !== siteId)) return;
    (_rsJ_(r['Столы'], []) || []).forEach(function (t) { out[String(t)] = { waiterId: String(r.WaiterID), waiter: String(r['Официант'] || ''), assignId: String(r.AssignID) }; });
  });
  return out;
}
/** Сотрудник по номеру (тот же, что в сессии): {id, name, role} или null. Справочник прав — без ключа входа (getEmployees его требует). */
function _rsEmp_(id) {
  try { var e = _mcRbEmpState_()[String(id || '')]; return e && e.active !== false && !e.hidden ? { id: String(id), name: String(e.name || ''), role: String(e.role || '') } : null; } catch (x) { return null; }
}
function _rsWaitersActive_() {
  var out = [], st = {}; try { st = _mcRbEmpState_(); } catch (e) {}
  Object.keys(st).forEach(function (id) { var e = st[id]; if (e && e.active !== false && !e.hidden && /официант/i.test(String(e.role || e.position || ''))) out.push({ id: id, name: String(e.name || ''), role: String(e.role || '') }); });
  return out;
}
/** Смена и закрепление столов на день: {date, siteId}. */
function rsShiftTables(json, token) {
  return _rsRead_(token, 'hall_view|order_edit|order_all', function (s) {
    var d = _rsJ_(json, {}) || {}, siteId = _rsSite_(d.siteId), day = _rsDay_(d.date) || _rsToday_(), sh = _rsOnShift_(siteId, day, '');
    var cands = sh.has ? sh.list.filter(function (x) { return x.group === 'hall' && /официант/i.test(x.role); }).map(function (x) { return { id: x.id, name: x.name, start: x.start, end: x.end, inSchedule: true }; })
      : _rsWaitersActive_().map(function (x) { return { id: x.id, name: x.name, inSchedule: false }; });
    return { date: day, siteId: siteId, schedule: sh, waiters: cands, assign: _rsTableAssign_(siteId, day), can: { edit: _mcRbHasExact_(s, 'order_all') } };
  });
}
/** Закрепить столы за официантом на день: {idem, date, siteId, waiterId, tables[]} (tables [] — снять закрепление). */
function rsShiftTablesSave(json, token) {
  return _rsMutate_(token, 'order_all', 'RS_SHIFT_TABLES', json, function (c) {
    var d = c.d, siteId = _rsSite_(d.siteId), day = _rsDay_(d.date) || _rsToday_();
    if (day < _rsToday_()) return { fail: ['VALIDATION', 'Прошедший день не меняется'] };
    var sh = _rsOnShift_(siteId, day, ''), wid = String(d.waiterId || ''), w = null;
    if (sh.has) { w = sh.list.filter(function (x) { return x.id === wid && x.group === 'hall'; })[0]; if (!w) return { fail: ['VALIDATION', 'Официанта нет в графике смен на ' + day.split('-').reverse().join('.') + ' — сначала поставьте его в «График смен»'] }; }
    else { w = _rsWaitersActive_().filter(function (x) { return x.id === wid; })[0]; if (!w) return { fail: ['VALIDATION', 'Официант не найден'] }; }
    var tidx = _rsTablesIdx_(), tables = (Array.isArray(d.tables) ? d.tables : []).map(String).filter(function (t, i, a) { return a.indexOf(t) === i; });
    for (var i = 0; i < tables.length; i++) { var t = tidx[tables[i]]; if (!t || t.status !== 'ACTIVE' || t.siteId !== siteId) return { fail: ['VALIDATION', 'Стол не найден на этой площадке'] }; }
    var rows = _rsRows_(MC_RS_SH_.TABLEASSIGN).filter(function (r) { return String(r['Статус']) === 'ACTIVE' && _rsDay_(r['Дата']) === day && String(r.SiteID) === siteId; }), plan = [], moved = [];
    var mine = rows.filter(function (r) { return String(r.WaiterID) === wid; })[0];
    rows.forEach(function (r) {
      if (r === mine) return;
      var ts = _rsJ_(r['Столы'], []) || [], left = ts.filter(function (x) { return tables.indexOf(String(x)) < 0; });
      if (left.length === ts.length) return;
      ts.filter(function (x) { return tables.indexOf(String(x)) >= 0; }).forEach(function (x) { moved.push({ table: tidx[x] ? tidx[x].number : x, from: String(r['Официант']) }); });
      var o = _rsCopy_(r); delete o._row; o['Столы'] = JSON.stringify(left); if (!left.length) o['Статус'] = 'CANCELLED'; _rsStamp_(o, c.s, c.op, false); plan.push({ sheet: MC_RS_SH_.TABLEASSIGN, row: o });
    });
    var row = mine ? _rsCopy_(mine) : { AssignID: _rsId_('TA'), 'Дата': day, SiteID: siteId, WaiterID: wid, 'Официант': w.name };
    delete row._row; row['Столы'] = JSON.stringify(tables); row['Статус'] = tables.length ? 'ACTIVE' : 'CANCELLED'; _rsStamp_(row, c.s, c.op, !mine);
    if (mine || tables.length) plan.push({ sheet: MC_RS_SH_.TABLEASSIGN, row: row });
    var nums = tables.map(function (x) { return tidx[x].number; });
    plan.push({ sheet: MC_RS_SH_.EVENTS, row: _rsEventRow_(c.op, c.s, 'SHIFT_TABLES', row.AssignID, null, 'SHIFT_TABLES_SET', null, { date: day, waiter: w.name, tables: nums, moved: moved }) });
    return { data: { waiter: w.name, tables: nums, moved: moved, inSchedule: sh.has }, plan: plan,
      audit: { action: 'RS_SHIFT_TABLES', entity: MC_RS_SH_.TABLEASSIGN, id: row.AssignID, after: { date: day, waiterId: wid, tables: nums } } };
  });
}
/** Для открытия стола: официант по закреплению и предупреждения. */
function _rsOpenWaiter_(s, t, waiter, explicit) {
  var day = _rsToday_(), warn = [], asg = null, sh = { has: false, list: [] };
  try { asg = _rsTableAssign_(t.siteId, day)[t.id] || null; } catch (e) {}
  if (asg && !explicit && asg.waiterId !== waiter.id) {
    if (_mcRbHasExact_(s, 'order_all')) waiter = { id: asg.waiterId, name: asg.waiter };
    else warn.push('Стол № ' + t.number + ' закреплён на сегодня за ' + asg.waiter);
  }
  try { sh = _rsOnShift_(t.siteId, day, _rsNowHm_()); } catch (e) {}
  if (sh.has) { var mine = sh.list.filter(function (x) { return x.id === waiter.id; });
    if (!mine.length) warn.push(waiter.name + ' — нет в графике смен на сегодня');
    else if (!mine.some(function (x) { return x.now; })) warn.push(waiter.name + ' — нет в графике смен на сейчас (смена ' + mine.map(function (x) { return x.start + '–' + x.end; }).join(', ') + ')'); }
  return { waiter: waiter, warnings: warn };
}

MC_GATE_EXT_.rsShiftTables = { need: 'hall_view|order_edit|order_all' };
MC_GATE_EXT_.rsShiftTablesSave = { need: 'order_all', mut: true };
